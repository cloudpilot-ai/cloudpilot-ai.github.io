# karpenter

Karpenter GCP Cloud Provider — cost-efficient autoscaling for GKE clusters

Karpenter GCP is an open-source node provisioning provider for GKE clusters. It watches for unschedulable pods and automatically provisions cost-efficient GCP nodes to meet workload requirements, removing them when they are no longer needed.

## Prerequisites

- Kubernetes 1.26+
- GKE cluster
- GCP service account with Compute Engine permissions (or Workload Identity)

## Installation

Add the Helm repository:

```bash
helm repo add karpenter-gcp https://cloudpilot-ai.github.io/karpenter-provider-gcp
helm repo update
```

Install the chart:

```bash
helm install karpenter karpenter-gcp/karpenter \
  --namespace karpenter \
  --create-namespace \
  --set controller.settings.projectID=<your-gcp-project> \
  --set controller.settings.clusterName=<your-cluster-name> \
  --set controller.settings.clusterLocation=<your-region-or-zone>
```

## Authentication

### Workload Identity (recommended)

Bind your GCP service account to the Karpenter Kubernetes service account:

```bash
gcloud iam service-accounts add-iam-policy-binding \
  karpenter@<PROJECT_ID>.iam.gserviceaccount.com \
  --role roles/iam.workloadIdentityUser \
  --member "serviceAccount:<PROJECT_ID>.svc.id.goog[karpenter/karpenter]"
```

Then annotate the service account and disable the credentials secret:

```bash
helm install karpenter karpenter-gcp/karpenter \
  --set serviceAccount.annotations."iam\.gke\.io/gcp-service-account"=karpenter@<PROJECT_ID>.iam.gserviceaccount.com \
  --set credentials.enabled=false \
  ...
```

### Service Account Key

Create a Kubernetes secret from your service account key file and reference it:

```bash
kubectl create secret generic karpenter-gcp-credentials \
  --from-file=key.json=/path/to/key.json \
  -n karpenter
```

```bash
helm install karpenter karpenter-gcp/karpenter \
  --set credentials.secretName=karpenter-gcp-credentials \
  ...
```

## Prometheus Operator Integration

Enable automatic metric scraping with a ServiceMonitor when using the [Prometheus Operator](https://github.com/prometheus-operator/prometheus-operator):

```bash
helm install karpenter karpenter-gcp/karpenter \
  --set serviceMonitor.enabled=true \
  ...
```

The ServiceMonitor requires the Prometheus Operator CRDs (`monitoring.coreos.com/v1`) to be installed in your cluster.

Add labels to match your Prometheus instance's selector:

```yaml
serviceMonitor:
  enabled: true
  additionalLabels:
    release: prometheus
```

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| additionalAnnotations | object | `{}` | Additional annotations to add into metadata for templated resources (excludes CRDs). |
| additionalLabels | object | `{}` | Additional labels to add into metadata for templated resources (excludes CRDs). Labels that the chart adds by default will not be overridden by these additional labels. |
| controller.affinity.podAntiAffinity.requiredDuringSchedulingIgnoredDuringExecution[0].labelSelector.matchLabels."app.kubernetes.io/name" | string | `"karpenter"` |  |
| controller.affinity.podAntiAffinity.requiredDuringSchedulingIgnoredDuringExecution[0].topologyKey | string | `"kubernetes.io/hostname"` |  |
| controller.disableControllerWarmup | bool | `true` | disableControllerWarmup controls whether controller sources (watches/informers) start before leader election is won. Set to false to enable warmup, which pre-populates caches and improves leader failover time. Default true matches karpenter-core default (warmup disabled). |
| controller.env | list | `[]` |  |
| controller.featureGates.capacityBuffer | bool | `false` | capacityBuffer is ALPHA and is disabled by default. Setting this to true enables CapacityBuffer support for pre-provisioning spare capacity. This provider does not install the CapacityBuffer CRD (GKE provides it natively starting at 1.35.2-gke.1842000) — enabling this on a cluster where the CRD isn't already installed fails at template render time. |
| controller.featureGates.nodeOverlay | bool | `false` | nodeOverlay is ALPHA and is disabled by default. Setting this will allow the use of node overlay to impact scheduling decisions |
| controller.featureGates.nodeRepair | bool | `false` | nodeRepair is ALPHA and is disabled by default. When enabled, Karpenter replaces nodes that fail GKE Node Problem Detector health conditions. Repairs respect disruption budgets and replacement capacity, but skip draining unhealthy nodes. |
| controller.featureGates.podDeletionCostManagement | bool | `false` | podDeletionCostManagement is ALPHA and is disabled by default. Manages pod-deletion-cost annotations so ReplicaSet scale-down prefers nodes targeted for consolidation. When enabled, existing pod-deletion-cost annotations no longer influence Karpenter disruption costs. |
| controller.featureGates.reservedCapacity | bool | `false` | reservedCapacity enables scheduling to reserved/committed GCP capacity. Disabled: the GCP provider does not yet implement GCE reservation support (#239). |
| controller.featureGates.spotToSpotConsolidation | bool | `true` |  |
| controller.featureGates.staticCapacity | bool | `false` | staticCapacity is ALPHA and is disabled by default. When enabled, a NodePool with spec.replicas set maintains a fixed number of nodes regardless of pod demand (static node pool). consolidationPolicy and consolidateAfter are ignored on static NodePools. |
| controller.featureGates.terminateFirstDrift | bool | `false` | terminateFirstDrift is ALPHA and is disabled by default. Allows drift to terminate a node before launching its replacement on a capacity-constrained NodePool. |
| controller.featureGates.terminateFirstRepair | bool | `false` | terminateFirstRepair is ALPHA and is disabled by default. Allows repair to terminate an unhealthy node before launching its replacement on a capacity-constrained NodePool. Only takes effect with nodeRepair enabled and legacyNodeRepair disabled. |
| controller.healthProbe.port | int | `8081` |  |
| controller.image.pullPolicy | string | `"IfNotPresent"` |  |
| controller.image.repository | string | `"public.ecr.aws/cloudpilotai/gcp/karpenter"` |  |
| controller.image.tag | string | `""` |  |
| controller.metrics.port | int | `8080` |  |
| controller.priorityClassName | string | `"gmp-critical"` |  |
| controller.replicaCount | int | `2` |  |
| controller.resources.requests.cpu | string | `"500m"` |  |
| controller.resources.requests.memory | string | `"500Mi"` |  |
| controller.revisionHistoryLimit | int | `10` |  |
| controller.settings.batchIdleDuration | string | `"1s"` | The maximum amount of time with no new ending pods that if exceeded ends the current batching window. If pods arrive faster than this time, the batching window will be extended up to the maxDuration. If they arrive slower, the pods will be batched separately. |
| controller.settings.batchMaxDuration | string | `"10s"` | The maximum length of a batch window. The longer this is, the more pods we can consider for provisioning at one time which usually results in fewer but larger nodes. |
| controller.settings.clusterLocation | string | `""` | The GCP region for instance type discovery (e.g., us-central1) |
| controller.settings.clusterName | string | `""` | The GCP cluster name. |
| controller.settings.defaultNodePoolTemplateName | string | `""` | Pin the GKE node pool used as the bootstrap metadata source. When set, Karpenter uses this pool exclusively and returns an error if it is not RUNNING. Leave empty to use automatic discovery (default-pool → first alphabetical RUNNING pool → fallback karpenter-fallback creation). |
| controller.settings.defaultNodepoolServiceAccount | string | `""` | Default GCP service account email to attach to provisioned nodes. When set, overrides the Compute Engine default SA. Corresponds to the DEFAULT_NODEPOOL_SERVICE_ACCOUNT env var. Recommended: set to a dedicated SA with roles/container.nodeServiceAccount. Can be overridden per-NodeClass via GCENodeClass.spec.serviceAccount. |
| controller.settings.ignoreDRARequests | bool | `true` | ignoreDRARequests controls whether Karpenter ignores pods' Dynamic Resource Allocation requests during scheduling simulations. Keep true unless the cluster has DRA drivers and resource claims that Karpenter should account for. |
| controller.settings.ipSpaceExhaustedTTL | string | `""` | How long an instance type, zone and capacity type stays unavailable after a launch fails with IP_SPACE_EXHAUSTED on every pod range (e.g. `1m`). Leave empty for the controller default of 30s. Must be positive. Corresponds to the IP_SPACE_EXHAUSTED_TTL env var. |
| controller.settings.launchTimeout | string | `""` | How long a NodeClaim may keep failing to launch with a non-capacity error before it is deleted and replaced (e.g. `10m`). Leave empty for the controller default of 5m. Must be positive. Corresponds to the LAUNCH_TIMEOUT env var. |
| controller.settings.legacyNodeRepair | bool | `false` | Run the legacy forceful node repair controller instead of budgeted voluntary repair. Only takes effect with nodeRepair enabled. Terminate-first repair is ignored in legacy mode. |
| controller.settings.nodeLocation | string | `""` | The exact GCP cluster location for GKE API calls (e.g., us-central1-a for zonal, us-central1 for regional). If not set, defaults to 'clusterLocation' for backward compatibility. |
| controller.settings.preferencePolicy | string | `"Respect"` | preferencePolicy controls how Karpenter handles soft scheduling preferences. `Respect` is the default; `Ignore` disregards preferred node/pod affinity and anti-affinity plus ScheduleAnyway topology spread constraints. |
| controller.settings.projectID | string | `""` | The GCP project ID. |
| controller.settings.quotaExceededTTL | string | `""` | How long an instance type stays unavailable in the region after a launch fails with QUOTA_EXCEEDED (e.g. `1h`). Leave empty for the controller default of 30m; set to `0s` to disable quota backoff. Corresponds to the QUOTA_EXCEEDED_TTL env var. |
| controller.settings.schedulerConfig | object | `{}` | Optional kube-scheduler behavior to mirror during scheduling simulations. Supports podTopologySpread.defaultConstraints; leave empty unless matching a known cluster scheduler configuration. |
| controller.settings.stockoutTTL | string | `""` | How long an instance type, zone and capacity type stays unavailable after a launch fails with ZONE_RESOURCE_POOL_EXHAUSTED (e.g. `2m`). Leave empty for the controller default of 5m. Must be positive. Corresponds to the STOCKOUT_TTL env var. |
| controller.settings.telemetry | bool | `false` | Send anonymized resource totals and Spot interruption events to CloudPilot AI. Off by default. See docs/settings.md#telemetry for exactly what is sent. Corresponds to the TELEMETRY env var. |
| controller.settings.unsupportedConfigurationTTL | string | `""` | How long an instance type, zone and capacity type stays unavailable after GCE reports the zone does not support the requested configuration (e.g. `6h`). Leave empty for the controller default of 1h. Must be positive. Corresponds to the UNSUPPORTED_CONFIGURATION_TTL env var. |
| controller.settings.vmMemoryOverheadPercent | float | `0.065` | The VM memory overhead as a percent that will be subtracted from the total memory for all instance types. The value of `0.075` equals to 7.5%. |
| controller.strategy.rollingUpdate.maxUnavailable | int | `1` |  |
| controller.terminationGracePeriodSeconds | int | `30` |  |
| controller.tolerations | list | `[]` |  |
| controller.topologySpreadConstraints | list | `[]` |  |
| credentials | object | `{"enabled":true,"secretKey":"key.json","secretName":""}` | GCP credentials configuration |
| credentials.enabled | bool | `true` | Enable or disable the use of GCP credentials secret Set to true if you want to use a Kubernetes secret for GCP authentication Set to false to rely on other authentication methods (e.g., Workload Identity, instance metadata) |
| credentials.secretKey | string | `"key.json"` | Key within the secret that contains the service account JSON |
| credentials.secretName | string | `""` | Name of the existing secret containing GCP credentials If not specified, defaults to "<release-name>-gcp-credentials" This secret should contain a service account key file |
| fullnameOverride | string | `""` |  |
| imagePullSecrets | list | `[]` |  |
| logErrorOutputPaths | list | `["stderr"]` | Log errorOutputPaths - defaults to stderr only |
| logLevel | string | `"info"` | Global log level, defaults to 'info' |
| logOutputPaths | list | `["stdout"]` | Log outputPaths - defaults to stdout only |
| nameOverride | string | `""` |  |
| node-problem-detector | object | `{"enabled":false,"hostNetwork":true,"nodeSelector":{"karpenter.sh/capacity-type":"spot"},"resources":{"limits":{"memory":"64Mi"},"requests":{"cpu":"10m","memory":"32Mi"}},"securityContext":{"allowPrivilegeEscalation":false,"capabilities":{"drop":["ALL"]},"privileged":false,"readOnlyRootFilesystem":true},"tolerations":[{"operator":"Exists"}],"volume":{"localtime":{"enabled":false}}}` | Optional node-problem-detector deployment that watches the GCE metadata server for Spot preemption notices and sets the GCESpotPreempting node condition, which Karpenter's interruption controller reacts to. Pair it with `GCENodeClass.spec.preemptionNoticeDuration: 120s` for a two-minute drain window. Uses ports 20258 (Prometheus) and 20259 (server) to avoid GKE's managed detector. See docs/spot-preemption.md. |
| node-problem-detector.enabled | bool | `false` | Deploy node-problem-detector with the Spot preemption plugin. Off by default: GKE Standard node pools already run their own node-problem-detector, so enabling this adds a second one. It only lands on nodes matching `nodeSelector`. |
| node-problem-detector.hostNetwork | bool | `true` | Required. The plugin reads the metadata server directly, which pods cannot do through the GKE metadata server. |
| node-problem-detector.nodeSelector | object | `{"karpenter.sh/capacity-type":"spot"}` | Only Spot nodes need the detector; on-demand instances are never preempted. |
| node-problem-detector.resources | object | `{"limits":{"memory":"64Mi"},"requests":{"cpu":"10m","memory":"32Mi"}}` | Resource requests and limits for the detector. |
| node-problem-detector.securityContext | object | `{"allowPrivilegeEscalation":false,"capabilities":{"drop":["ALL"]},"privileged":false,"readOnlyRootFilesystem":true}` | The plugin only needs network access, so drop the chart's default privileged pod. |
| node-problem-detector.tolerations | list | `[{"operator":"Exists"}]` | Tolerate every taint so the detector reaches Spot nodes regardless of workload taints. |
| node-problem-detector.volume | object | `{"localtime":{"enabled":false}}` | Not needed by the preemption plugin. |
| podAnnotations | object | `{}` |  |
| podDisruptionBudget.maxUnavailable | integer or string | `nil` | Maximum number of unavailable pods. When set, takes precedence over minAvailable. |
| podDisruptionBudget.minAvailable | int | `1` | Minimum number of available pods. Used when maxUnavailable is not set. |
| podLabels | object | `{}` |  |
| podSecurityContext | object | `{"runAsNonRoot":true,"seccompProfile":{"type":"RuntimeDefault"}}` | Security context applied at the pod level. |
| securityContext | object | `{"allowPrivilegeEscalation":false,"capabilities":{"drop":["ALL"]},"readOnlyRootFilesystem":true,"runAsNonRoot":true,"seccompProfile":{"type":"RuntimeDefault"}}` | Security context applied to the karpenter container. |
| serviceAccount.annotations | object | `{}` |  |
| serviceAccount.automount | bool | `true` |  |
| serviceAccount.create | bool | `true` |  |
| serviceAccount.name | string | `""` |  |
| serviceMonitor.additionalLabels | object | `{}` | Additional labels for the ServiceMonitor. |
| serviceMonitor.enabled | bool | `false` | Specifies whether a ServiceMonitor should be created. |
| serviceMonitor.interval | string | `""` | Scrape interval for the `http-metrics` endpoint. Empty string uses the Prometheus operator's default (typically 30s). |
| serviceMonitor.metricRelabelings | list | `[]` | Metric relabelings for the `http-metrics` endpoint on the ServiceMonitor. For more details on metric relabelings, see: https://prometheus.io/docs/prometheus/latest/configuration/configuration/#metric_relabel_configs |
| serviceMonitor.relabelings | list | `[]` | Relabelings for the `http-metrics` endpoint on the ServiceMonitor. For more details on relabelings, see: https://prometheus.io/docs/prometheus/latest/configuration/configuration/#relabel_config |
| serviceMonitor.sampleLimit | string | `nil` | Specifies the sampleLimit for prometheus scrapes. Per-scrape limit on the number of scraped samples that will be accepted. If more than this number of samples are present after metric relabeling the entire scrape will be treated as failed. 0 means no limit. |
| serviceMonitor.scrapeTimeout | string | `""` | Scrape timeout for the `http-metrics` endpoint. Empty string uses the Prometheus operator's default (typically 10s). |
